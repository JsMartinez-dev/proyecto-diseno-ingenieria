# PLAN GENERAL DE IMPLEMENTACIÓN E INFRAESTRUCTURA — ALIADO

**Proyecto:** ALIADO - Plataforma para la gestión y contratación confiable de servicios técnicos a domicilio en Santa Marta  
**Programa:** Ingeniería de Sistemas - Universidad del Magdalena  
**Periodo:** 2026-2  
**Fecha del plan general:** 2026-10-02  


---

## 1. Propósito del documento

Este documento consolida en un único plan técnico la arquitectura, infraestructura, módulos, dependencias, datos, seguridad, despliegue, pruebas y orden de implementación de ALIADO para el alcance actualmente especificado en los SPEC-01 a SPEC-09.

El objetivo no es reemplazar los planes individuales de cada SPEC. Los planes individuales siguen siendo la fuente de detalle para sus historias, endpoints y tareas; este documento define la **visión integral del sistema** y las decisiones transversales necesarias para que todas las piezas evolucionen de forma coherente.

La solución se organiza como un **monolito modular**, con un backend único consumido por una aplicación móvil React Native para Cliente/Prestador y un panel web React para Administración. La persistencia principal es PostgreSQL y el despliegue inicial se realiza mediante contenedores Docker sobre VPS.

---

## 2. Contexto y objetivo de ingeniería

ALIADO busca reducir la fragmentación actual de la gestión de servicios técnicos a domicilio en Santa Marta. El sistema debe permitir que:

- un Cliente se registre, gestione su privacidad y publique solicitudes;
- un Cliente pueda descubrir Prestadores sin exponer datos privados;
- un Prestador gestione su perfil profesional, disponibilidad y portafolio;
- el sistema calcule oportunidades compatibles entre solicitudes y Prestadores;
- un Prestador cree, edite o retire propuestas;
- un Cliente acepte una propuesta y formalice un servicio;
- Cliente y Prestador gestionen de manera controlada el ciclo de vida del servicio;
- el sistema mantenga historial y consistencia de los cambios de estado;
- las partes reciban notificaciones asociadas a eventos reales del sistema;
- la solución pueda crecer posteriormente hacia reputación, moderación, administración y capacidades futuras sin rehacer su núcleo.

### 2.1 Usuarios principales

| Actor | Responsabilidad principal |
|---|---|
| Cliente | Buscar Prestadores, publicar solicitudes, consultar propuestas y contratar servicios |
| Prestador | Mantener perfil profesional, consultar oportunidades y presentar propuestas |
| Administrador | Moderación, auditoría, gestión de catálogos y funciones administrativas posteriores |

---

## 3. Alcance consolidado

### 3.1 Alcance cubierto por los SPEC actuales

| SPEC | Módulo | Capacidad |
|---|---|---|
| SPEC-01 | `auth` | Registro, autenticación, sesiones, recuperación y control por rol |
| SPEC-02 | `perfil` | Datos personales, privacidad, ubicación y eliminación de cuenta |
| SPEC-03 | `descubrimiento` | Búsqueda y consulta pública de Prestadores |
| SPEC-04 | `solicitudes` + `catalogo` | Creación, edición, cancelación y consulta de solicitudes |
| SPEC-05 | `perfiles` | Perfil profesional, portafolio, disponibilidad y agenda |
| SPEC-06 | `oportunidades` | Compatibilidad, tablero y detalle de oportunidades |
| SPEC-07 | `propuestas` | Creación, edición y retiro de propuestas |
| SPEC-08 | `servicios` | Contratación, ciclo de vida, historial y comunicación asociada |
| SPEC-09 | `notificaciones` | Notificaciones derivadas de aceptación y cambios de estado |

### 3.2 Alcance posterior ya previsto en el planteamiento del proyecto

La Plantilla-Proyecto-ALIADO contempla adicionalmente:

- calificaciones y reputación;
- reportes y moderación;
- auditoría administrativa;
- administración de categorías y zonas;
- formalización progresiva;
- preferencias de notificación;
- historial extendido;
- capacidades Could/Future.

Estas capacidades deberán integrarse usando los puntos de extensión definidos en este plan, pero **no se consideran implementadas por los SPEC-01 a SPEC-09**.

---

## 4. Principios arquitectónicos

1. **Monolito modular antes que microservicios.**  
   La escala del piloto no justifica la complejidad operacional de microservicios. Los dominios se separan por paquetes y contratos internos.

2. **Una sola fuente de verdad por concepto.**  
   `Solicitud`, `PerfilProfesional`, `Propuesta`, `ServicioContratado` y `Notificacion` no deben duplicarse en otros módulos.

3. **Dependencias explícitas entre dominios.**  
   Los módulos consumen servicios o interfaces públicas de otros módulos en lugar de acceder arbitrariamente a sus tablas.

4. **Privacidad por diseño.**  
   La dirección exacta y los datos de contacto no forman parte de DTO públicos.

5. **Cambios de estado transaccionales.**  
   Toda transición crítica debe quedar en la misma transacción que su registro de historial y evento persistente asociado.

6. **Idempotencia en operaciones sensibles.**  
   Reintentos causados por conectividad débil no deben duplicar solicitudes, propuestas, servicios ni notificaciones.

7. **Infraestructura sustituible mediante interfaces.**  
   Archivos, notificaciones y otros proveedores externos se abstraen detrás de contratos internos.

8. **Observabilidad desde el inicio.**  
   Logs estructurados, métricas, health checks y trazabilidad de errores forman parte de la infraestructura base.

9. **Optimización para móvil y conectividad intermitente.**  
   Las APIs deben tolerar reintentos, payloads moderados y paginación.

10. **Evolución incremental.**  
    Las capacidades futuras se añaden como módulos sin modificar de manera destructiva el núcleo del MVP.

---

## 5. Arquitectura de alto nivel

```mermaid
flowchart TB
    C[Cliente]
    P[Prestador]
    A[Administrador]

    C --> M[App móvil React Native]
    P --> M
    A --> W[Panel web React]

    M --> RP[Reverse Proxy / TLS]
    W --> RP

    RP --> API[Backend Java 21 / Spring Boot 3.3]

    API --> PG[(PostgreSQL 16)]
    API --> OBJ[(Storage S3-compatible)]
    API --> PUSH[Proveedor de notificaciones]
    API --> MAIL[Proveedor de correo]

    API --> OBS[Logs + métricas + health checks]

    subgraph Backend modular
      AUTH[auth]
      PERF[perfil]
      CAT[catalogo]
      SOL[solicitudes]
      PRO[perfiles profesionales]
      DESC[descubrimiento]
      OPP[oportunidades]
      PROP[propuestas]
      SERV[servicios]
      NOTIF[notificaciones]
      COMMON[common]
    end
```

---

## 6. Decisiones tecnológicas consolidadas

### 6.1 Tecnologías base confirmadas por los planes

| Capa | Tecnología |
|---|---|
| Lenguaje backend | Java 21 LTS |
| Framework backend | Spring Boot 3.3.x |
| API | REST/JSON |
| Persistencia | PostgreSQL 16 |
| ORM | Spring Data JPA / Hibernate |
| Migraciones | Flyway |
| Seguridad | Spring Security + BCrypt |
| Validación | Spring Validation |
| Build | Maven |
| Unit testing | JUnit 5 + Mockito |
| Integration testing | Spring Boot Test + Testcontainers |
| Contract/API testing | MockMvc o WebTestClient |
| App móvil | React Native |
| Panel administrativo | React |
| Contenedores | Docker |
| Orquestación inicial | Docker Compose |
| Plataforma inicial | VPS |

### 6.2 Decisiones propuestas por este plan general

Estas decisiones cierran vacíos identificados expresamente en los SPEC y deberán ratificarse antes de implementación productiva.

#### Sesiones

**Decisión propuesta:** usar **token opaco de sesión** generado criptográficamente y almacenado únicamente como hash en la tabla `sesiones`.

Razones:

- el modelo de SPEC-01 ya define `Sesion.tokenHash`;
- facilita revocación inmediata;
- evita mantener JWT activos imposibles de invalidar antes de expirar;
- simplifica logout y control de sesión para el piloto.

El cliente recibe el token en el login y lo envía mediante:

```http
Authorization: Bearer <opaque-session-token>
```

#### Almacenamiento de archivos

**Decisión propuesta:** contrato `ArchivoStorageService` con backend S3-compatible.

Implementación por entorno:

- desarrollo: MinIO local;
- piloto en VPS: MinIO o proveedor S3-compatible externo;
- evolución: cualquier servicio compatible con S3 sin cambiar la lógica del dominio.

El sistema persiste únicamente metadata/URL/clave de objeto, nunca blobs binarios dentro de PostgreSQL.

#### Notificaciones

**Decisión propuesta:** unificar SPEC-06, SPEC-07 y SPEC-09 bajo el módulo genérico `notificaciones`.

Modelo objetivo:

- `Notificacion`
- `EventoNotificable`/clave de idempotencia
- `CanalEntregaNotificacion`
- adaptador push
- adaptador de correo si aplica

Durante la transición pueden mantenerse las tablas puntuales existentes, pero no deben convertirse en el patrón definitivo.

**Canal principal propuesto para la app:** push móvil mediante Firebase Cloud Messaging.  
**Canal secundario:** correo para recuperación de acceso y eventos que requieran respaldo.

#### Entrega confiable de eventos

Para evitar que una transacción de negocio quede acoplada a la disponibilidad de FCM/correo, se adopta:

- persistencia atómica de la notificación dentro de la transacción de negocio;
- entrega asíncrona posterior;
- reintentos con backoff;
- clave de idempotencia;
- estado `PENDIENTE`, `ENTREGADA`, `FALLIDA`.

Para una evolución futura, este mecanismo puede formalizarse como **Transactional Outbox** sin introducir un broker externo en el MVP.

---

## 7. Estructura lógica del repositorio

```text
aliado/
├── backend/
│   ├── pom.xml
│   ├── src/main/java/com/aliado/
│   │   ├── auth/
│   │   │   ├── controller/
│   │   │   ├── service/
│   │   │   ├── repository/
│   │   │   ├── model/
│   │   │   └── dto/
│   │   ├── perfil/
│   │   ├── catalogo/
│   │   ├── solicitudes/
│   │   ├── perfiles/
│   │   ├── descubrimiento/
│   │   ├── oportunidades/
│   │   ├── propuestas/
│   │   ├── servicios/
│   │   ├── notificaciones/
│   │   └── common/
│   │       ├── config/
│   │       ├── security/
│   │       ├── exception/
│   │       ├── storage/
│   │       ├── idempotency/
│   │       ├── observability/
│   │       └── util/
│   ├── src/main/resources/
│   │   ├── db/migration/
│   │   ├── application.yml
│   │   ├── application-dev.yml
│   │   └── application-prod.yml
│   └── src/test/
│       ├── unit/
│       ├── integration/
│       └── contract/
│
├── app-movil/
│   ├── src/
│   │   ├── auth/
│   │   ├── cliente/
│   │   ├── prestador/
│   │   ├── shared/
│   │   ├── services/
│   │   └── storage/
│   └── tests/
│
├── panel-admin/
│   ├── src/
│   │   ├── auth/
│   │   ├── pages/
│   │   ├── components/
│   │   ├── services/
│   │   └── modules/
│   └── tests/
│
├── infra/
│   ├── docker/
│   ├── nginx/
│   ├── monitoring/
│   ├── backup/
│   └── scripts/
│
├── docs/
│   ├── architecture/
│   ├── api/
│   ├── decisions/
│   └── operations/
│
├── docker-compose.yml
├── docker-compose.prod.yml
└── README.md
```

---

## 8. Mapa de módulos del backend

### 8.1 `auth`

Responsabilidades:

- registro por rol;
- consentimiento inicial;
- login/logout;
- sesiones;
- recuperación de contraseña;
- autorización base por rol.

Entidades:

- `Usuario`
- `Consentimiento`
- `Sesion`
- `TokenRecuperacion`

No debe contener datos de perfil personal o profesional.

### 8.2 `perfil`

Responsabilidades:

- datos personales;
- ubicación;
- privacidad;
- eliminación de cuenta.

Entidades:

- `PerfilUsuario`
- `Ubicacion`
- `SolicitudEliminacion`

Regla crítica: `direccionExacta` nunca se entrega desde una vista pública.

### 8.3 `catalogo`

Responsabilidades:

- categorías de servicio;
- zonas;
- futura administración de estos catálogos.

Entidades:

- `CategoriaServicio`
- `Zona`

Este módulo nace en SPEC-04 y se reutiliza en solicitudes, perfiles, descubrimiento y compatibilidad.

### 8.4 `solicitudes`

Responsabilidades:

- borrador/publicación;
- edición;
- cancelación;
- consulta del Cliente;
- fotos de la solicitud;
- historial de estado.

Entidades:

- `Solicitud`
- `FotoSolicitud`
- `HistorialEstadoSolicitud`

### 8.5 `perfiles`

Responsabilidades:

- perfil profesional;
- categorías ofrecidas;
- zonas de atención;
- experiencia;
- portafolio;
- disponibilidad;
- agenda;
- DTO de perfil público.

Entidades:

- `PerfilProfesional`
- `PerfilCategoria`
- `PerfilZonaAtencion`
- `ExperienciaProfesional`
- `ServicioPortafolio`
- `Disponibilidad`
- `CompromisoAgenda`

### 8.6 `descubrimiento`

Módulo de lectura.

Responsabilidades:

- búsqueda de Prestadores;
- filtros por categoría/zona;
- construcción de perfil público;
- ocultamiento sistemático de datos privados.

No tiene entidades persistentes propias.

### 8.7 `oportunidades`

Responsabilidades:

- calcular compatibilidad;
- construir tablero;
- filtrar oportunidades;
- detalle de oportunidad;
- generar evento de oportunidad compatible.

La oportunidad es una proyección de una `Solicitud`, no una tabla duplicada.

### 8.8 `propuestas`

Responsabilidades:

- crear propuesta;
- editar propuesta;
- retirar propuesta;
- validar solicitud abierta;
- validar compatibilidad.

Entidad principal:

- `Propuesta`

### 8.9 `servicios`

Responsabilidades:

- aceptar propuesta;
- cerrar propuestas competidoras;
- crear servicio contratado;
- gestionar estados;
- registrar historial;
- habilitar comunicación;
- consultar mensajes del servicio.

Entidades:

- `ServicioContratado`
- `HistorialEstadoServicio`
- `MensajeServicio`

### 8.10 `notificaciones`

Responsabilidades:

- persistir avisos;
- asegurar idempotencia;
- seleccionar canal;
- entregar;
- reintentar;
- permitir consulta del historial de notificaciones.

Entidad objetivo:

- `Notificacion`

---

## 9. Grafo de dependencias funcionales

```mermaid
flowchart LR
    S1[SPEC-01 Auth]
    S2[SPEC-02 Perfil]
    S3[SPEC-03 Descubrimiento]
    S4[SPEC-04 Solicitudes + Catálogo + Storage]
    S5[SPEC-05 Perfil profesional]
    S6[SPEC-06 Oportunidades]
    S7[SPEC-07 Propuestas]
    S8[SPEC-08 Servicios]
    S9[SPEC-09 Notificaciones]

    S1 --> S2
    S1 --> S3
    S1 --> S4
    S1 --> S5

    S4 --> S5
    S4 --> S6
    S5 --> S6

    S5 --> S3
    S6 --> S7
    S4 --> S7

    S7 --> S8
    S4 --> S8
    S8 --> S2

    S8 --> S9
    S6 --> S9
    S7 --> S9
```

### 9.1 Dependencias bloqueantes

1. SPEC-01 Foundational debe existir antes de los demás módulos.
2. SPEC-04 debe establecer catálogo y almacenamiento antes de cerrar SPEC-05.
3. SPEC-05 debe estar listo antes del cálculo real de compatibilidad.
4. SPEC-06 debe existir antes de crear propuestas válidas.
5. SPEC-07 debe existir antes de contratar.
6. SPEC-08 debe existir antes de completar eliminación de cuenta y notificaciones de servicio.
7. SPEC-09 consolida la infraestructura de entrega de avisos.

---

## 10. Modelo de datos consolidado

### 10.1 Identidad y privacidad

```text
usuarios
consentimientos
sesiones
tokens_recuperacion
perfiles
ubicaciones
solicitudes_eliminacion
```

### 10.2 Catálogo y solicitudes

```text
categorias_servicio
zonas
solicitudes
fotos_solicitud
historial_estado_solicitud
```

### 10.3 Prestadores

```text
perfiles_profesionales
perfil_categoria
perfil_zona_atencion
experiencias_profesionales
servicios_portafolio
disponibilidades
compromisos_agenda
```

### 10.4 Propuestas y contratación

```text
propuestas
servicios_contratados
historial_estado_servicio
mensajes_servicio
```

### 10.5 Notificaciones

Modelo objetivo:

```text
notificaciones
```

Durante la migración pueden coexistir temporalmente:

```text
notificaciones_oportunidad
notificaciones_propuesta_recibida
```

pero deberán converger al módulo genérico.

---

## 11. Reglas de integridad principales

### Usuario

- `email` único.
- contraseña solo como hash BCrypt.
- el sistema no revela si un email existe durante recuperación.
- sesiones revocables.

### Perfil y privacidad

- relación 1:1 entre Usuario y PerfilUsuario.
- relación 1:1 entre Usuario y Ubicacion.
- `direccionExacta` cifrada en reposo.
- DTO públicos excluyen dirección exacta y contacto privado.

### Solicitud

Estados base:

```text
BORRADOR
PUBLICADA
CANCELADA
CONTRATADA
```

Reglas:

- solo solicitudes abiertas admiten edición/cancelación;
- una solicitud contratada no vuelve a estado publicado;
- toda transición relevante queda en historial.

### Propuesta

Estados:

```text
ACTIVA
RETIRADA
ACEPTADA
CERRADA
```

Reglas:

- una propuesta solo puede crearse para solicitud abierta y compatible;
- solo una propuesta puede resultar aceptada por solicitud;
- al aceptar una propuesta, las demás activas se cierran de forma atómica.

### Servicio

Estados:

```text
CONTRATADO
EN_EJECUCION
TERMINADO
FINALIZADO
CANCELADO
```

Se debe formalizar antes de implementación la transición exacta de `TERMINADO`, pendiente en SPEC-08.

Control de concurrencia:

- `@Version` sobre `ServicioContratado`;
- la transición + historial + generación de notificación se ejecutan atómicamente.

---

## 12. Contrato de privacidad de datos

### 12.1 Clasificación

| Clasificación | Ejemplos | Política |
|---|---|---|
| Pública | categoría, zona aproximada, portafolio | visible según reglas |
| Interna | IDs técnicos, estados, timestamps | solo API autenticada |
| Sensible | dirección exacta, teléfono, email | acceso mínimo necesario |
| Secreta | password hash, token hash, secretos de infraestructura | nunca expuesta |

### 12.2 Cifrado

**En tránsito**

- HTTPS obligatorio;
- TLS terminado en reverse proxy;
- HTTP interno permitido únicamente dentro de la red privada Docker si no sale del host.

**En reposo**

- secretos fuera del repositorio;
- campos sensibles seleccionados con cifrado a nivel de aplicación;
- backups cifrados;
- storage de objetos privado por defecto.

---

## 13. API y convenciones

Base:

```text
/api/v1
```

Convenciones:

- JSON UTF-8;
- fechas ISO-8601;
- IDs opacos;
- paginación para listas que puedan crecer;
- errores con formato único;
- autorización basada en rol y pertenencia;
- `404` genérico cuando distinguir inexistencia/propiedad pueda filtrar información;
- `409` para transición o concurrencia inválida;
- `422` puede reservarse para validación semántica futura; mantener `400` donde los SPEC ya lo fijan.

### 13.1 Formato estándar de error

```json
{
  "timestamp": "2026-10-02T18:00:00Z",
  "status": 409,
  "code": "INVALID_STATE_TRANSITION",
  "message": "La operación no puede ejecutarse en el estado actual.",
  "path": "/api/v1/servicios/123/en-ejecucion",
  "traceId": "..."
}
```

No incluir:

- stack traces;
- SQL;
- datos personales;
- existencia de recursos ajenos;
- detalles de credenciales.

---

## 14. Idempotencia y conectividad intermitente

RNF-001 exige tolerar conectividad móvil deficiente.

### 14.1 Operaciones que deben ser idempotentes o protegidas

- registro;
- publicación de solicitud;
- cancelación;
- creación de propuesta;
- retiro de propuesta;
- aceptación de propuesta;
- transición de servicio;
- notificación.

### 14.2 Estrategia

Para comandos susceptibles a reintentos:

```http
Idempotency-Key: <uuid-generado-en-cliente>
```

Servidor:

1. recibe la clave;
2. verifica si ya fue procesada;
3. si existe, devuelve el resultado anterior;
4. si no existe, procesa y registra la respuesta dentro de la misma transacción cuando sea viable.

La aplicación móvil conserva temporalmente comandos pendientes para poder reintentarlos.

---

## 15. Infraestructura de despliegue

### 15.1 Topología inicial del piloto

```mermaid
flowchart TB
    INTERNET[Internet]
    DNS[DNS]
    RP[Nginx/Caddy\nHTTPS + Reverse Proxy]
    API[aliado-api\nSpring Boot]
    DB[(PostgreSQL 16)]
    OBJ[(MinIO / S3)]
    WORKER[Notification Worker]
    MON[Monitoring]
    BAK[Backups]

    INTERNET --> DNS
    DNS --> RP
    RP --> API
    API --> DB
    API --> OBJ
    API --> WORKER
    API --> MON
    DB --> BAK
    OBJ --> BAK
```

### 15.2 Servicios Docker Compose

```yaml
services:
  reverse-proxy:
  backend:
  postgres:
  object-storage:
  notification-worker:
  monitoring:
```

Servicios opcionales por entorno:

```yaml
  mail-catcher:   # desarrollo
  pgadmin:        # solo desarrollo, nunca público
```

### 15.3 Red

Separar:

```text
public_net
backend_net
data_net
```

Reglas:

- solo reverse proxy publica 80/443;
- backend no expone su puerto directamente a Internet;
- PostgreSQL nunca es público;
- MinIO/S3 queda privado salvo URLs firmadas;
- paneles de monitoreo requieren autenticación y/o VPN/IP allowlist.

---

## 16. Configuración por entornos

### Desarrollo

```text
application-dev.yml
docker-compose.yml
```

Características:

- PostgreSQL en contenedor;
- MinIO;
- proveedor de correo local;
- logging DEBUG controlado;
- datos seed de desarrollo.

### Test

- Testcontainers para PostgreSQL;
- adapters falsos para storage/notificaciones;
- migraciones Flyway reales;
- dataset aislado por suite.

### Producción/piloto

```text
application-prod.yml
docker-compose.prod.yml
```

Variables sensibles:

```text
DB_URL
DB_USER
DB_PASSWORD
SESSION_SECRET
FIELD_ENCRYPTION_KEY
STORAGE_ENDPOINT
STORAGE_ACCESS_KEY
STORAGE_SECRET_KEY
FCM_CREDENTIALS
MAIL_PROVIDER_KEY
```

Nunca almacenar secretos reales en Git.

---

## 17. Reverse proxy y TLS

Responsabilidades:

- HTTPS;
- redirección HTTP → HTTPS;
- límites de tamaño;
- rate limiting básico;
- headers de seguridad;
- forwarding de IP;
- compresión;
- acceso únicamente al backend.

Headers mínimos:

```text
Strict-Transport-Security
X-Content-Type-Options
Content-Security-Policy   # panel web
Referrer-Policy
```

---

## 18. Infraestructura de archivos

Interfaz:

```java
public interface ArchivoStorageService {
    ArchivoGuardado guardar(Archivo archivo);
    void eliminar(String clave);
    URL generarUrlLecturaTemporal(String clave);
}
```

Reglas:

- validar MIME real;
- validar extensión;
- límite por tamaño;
- nombre generado por servidor;
- no confiar en nombre original;
- objetos privados;
- URL firmada con expiración;
- antivirus/escaneo puede añadirse posteriormente.

Usos actuales:

- fotos de solicitudes;
- evidencias de portafolio.

---

## 19. Infraestructura de notificaciones

### 19.1 Flujo objetivo

```mermaid
sequenceDiagram
    participant D as Dominio
    participant DB as PostgreSQL
    participant N as NotificacionService
    participant W as Worker
    participant F as FCM/Proveedor
    participant U as Usuario

    D->>DB: Ejecutar cambio de negocio
    D->>N: registrar evento notificable
    N->>DB: INSERT Notificacion(PENDIENTE)
    DB-->>D: COMMIT
    W->>DB: consultar pendientes
    W->>F: entregar
    F-->>W: resultado
    W->>DB: ENTREGADA/FALLIDA
    F-->>U: notificación
```

### 19.2 Tipos iniciales

```text
NUEVA_OPORTUNIDAD
PROPUESTA_RECIBIDA
ACEPTACION_PROPUESTA
CAMBIO_ESTADO_SERVICIO
```

### 19.3 Idempotencia

Clave recomendada:

```text
tipo + aggregateId + destinatarioId + eventVersion
```

No deben generarse dos notificaciones para el mismo evento lógico.

---

## 20. Observabilidad

### 20.1 Logs

Formato estructurado:

```json
{
  "timestamp": "...",
  "level": "INFO",
  "service": "aliado-api",
  "module": "servicios",
  "traceId": "...",
  "actorId": "...",
  "action": "SERVICE_STATE_CHANGED"
}
```

Nunca registrar:

- contraseñas;
- tokens;
- dirección exacta;
- contenido sensible innecesario.

### 20.2 Métricas mínimas

- requests por endpoint;
- latencia p50/p95/p99;
- tasa de errores 4xx/5xx;
- conexiones DB;
- pool de conexiones;
- notificaciones pendientes/fallidas;
- uso CPU/RAM;
- espacio de disco;
- tiempo de respuesta de storage;
- cantidad de sesiones activas.

### 20.3 Health checks

Spring Boot Actuator:

```text
/actuator/health
/actuator/health/readiness
/actuator/health/liveness
```

Los endpoints administrativos no deben ser públicos sin control.

---

## 21. Rendimiento

Objetivos ya definidos:

- login p95 < 300 ms;
- consulta de perfil propio p95 < 300 ms;
- descubrimiento por categoría/zona p95 < 300 ms;
- tablero y solicitudes deben permitir revisión ágil.

### Objetivo provisional del plan general

Hasta que RNF-003 tenga cifra definitiva:

```text
GET de lectura principal: p95 <= 500 ms bajo carga del piloto
comandos de negocio: p95 <= 800 ms excluyendo proveedores externos
```

Las entregas externas de push/correo son asíncronas y no deben formar parte de la latencia del comando principal.

### Índices iniciales

```text
usuarios(email)
sesiones(token_hash, estado, fecha_expiracion)
solicitudes(cliente_id, estado)
solicitudes(categoria_id, zona_id, estado)
perfil_categoria(categoria_id, perfil_id)
perfil_zona_atencion(zona_id, perfil_id)
propuestas(solicitud_id, estado)
propuestas(prestador_id, estado)
servicios_contratados(cliente_id, estado)
servicios_contratados(prestador_id, estado)
notificaciones(destinatario_id, estado_entrega)
```

Ajustar con `EXPLAIN ANALYZE`, no por intuición únicamente.

---

## 22. Seguridad

### 22.1 Autenticación

- BCrypt para contraseñas;
- token opaco aleatorio de alta entropía;
- token almacenado como hash;
- expiración;
- logout revoca sesión;
- recuperación con token de un solo uso;
- respuestas genéricas frente a credenciales.

### 22.2 Autorización

Primera capa:

```text
CLIENTE
PRESTADOR
ADMIN
```

Segunda capa: autorización por recurso.

Ejemplos:

- un Cliente solo modifica sus solicitudes;
- un Prestador solo modifica su propuesta;
- solo las partes de un servicio consultan mensajes;
- solo el Cliente propietario acepta propuestas;
- solo el Prestador del servicio marca ejecución/terminado.

### 22.3 Controles adicionales

- rate limit en login/recuperación;
- protección contra enumeración;
- validación de payload;
- sanitización de texto;
- tamaño máximo de archivos;
- headers de seguridad;
- dependencias escaneadas;
- cuentas de DB con privilegio mínimo.

---

## 23. Auditoría

Aunque la auditoría administrativa completa pertenece al alcance posterior, la infraestructura debe quedar preparada desde el MVP.

Eventos recomendados:

```text
USER_REGISTERED
LOGIN_SUCCESS
LOGIN_FAILED
ACCOUNT_DELETION_REQUESTED
REQUEST_PUBLISHED
REQUEST_CANCELLED
PROPOSAL_CREATED
PROPOSAL_WITHDRAWN
PROPOSAL_ACCEPTED
SERVICE_STATE_CHANGED
NOTIFICATION_FAILED
```

Para acciones administrativas futuras se deberá usar una tabla append-only de auditoría.

---

## 24. Backups y recuperación

### 24.1 PostgreSQL

Piloto:

- dump diario;
- retención mínima 7 días;
- copia semanal con retención ampliada;
- almacenamiento cifrado fuera del volumen principal.



### 24.2 Objetos

- bucket/versionado si el proveedor lo permite;
- copia independiente de evidencias críticas;
- política de eliminación coherente con privacidad.

### 24.3 Restauración

Debe existir un procedimiento documentado y probado:

1. levantar instancia limpia;
2. restaurar PostgreSQL;
3. restaurar objetos;
4. ejecutar validaciones;
5. verificar health checks;
6. comprobar integridad funcional.

Un backup no se considera válido si nunca se ha probado su restauración.

---

## 25. CI/CD

### 25.1 Pipeline backend

```text
Checkout
  ↓
Compile
  ↓
Unit tests
  ↓
Contract tests
  ↓
Integration tests + Testcontainers
  ↓
Static analysis
  ↓
Dependency scan
  ↓
Build JAR
  ↓
Build Docker image
  ↓
Deploy staging
  ↓
Smoke tests
  ↓
Deploy production/pilot
```

### 25.2 Quality gates

No desplegar si:

- falla compilación;
- falla Flyway validation;
- falla un contract test;
- falla un integration test crítico;
- existe vulnerabilidad crítica sin excepción documentada.

---

## 26. Estrategia de pruebas consolidada

### Unitarias

Probar lógica pura:

- hashing/verificación;
- reglas de estado;
- compatibilidad;
- disponibilidad;
- privacidad;
- idempotencia;
- generación de notificaciones.

### Integración

Con PostgreSQL real mediante Testcontainers:

- migraciones;
- constraints;
- transacciones;
- concurrencia;
- repositorios;
- flujo completo entre módulos.

### Contrato

Cada endpoint debe validar:

- status;
- shape;
- campos obligatorios;
- autorización;
- errores.

### E2E

Flujos críticos:

#### Flujo Cliente

```text
registro
→ login
→ perfil
→ solicitud
→ propuestas
→ aceptar
→ servicio
→ confirmar finalización
```

#### Flujo Prestador

```text
registro
→ login
→ perfil profesional
→ disponibilidad
→ oportunidades
→ propuesta
→ contratación
→ ejecutar servicio
→ terminar
```

---

## 27. Orden general de implementación

### Fase 0 — Preparación del repositorio

- [ ] PG-001 Crear estructura monorepo o repositorio coordinado.
- [ ] PG-002 Definir estrategia Git.
- [ ] PG-003 Configurar Maven y Java 21.
- [ ] PG-004 Crear `docker-compose.yml` de desarrollo.
- [ ] PG-005 Configurar PostgreSQL y Flyway.
- [ ] PG-006 Configurar CI base.
- [ ] PG-007 Configurar convenciones de API y errores.

### Fase 1 — Fundación de seguridad

Corresponde principalmente a SPEC-01.

- [ ] PG-008 Implementar `auth`.
- [ ] PG-009 Implementar Spring Security.
- [ ] PG-010 Implementar token opaco de sesión.
- [ ] PG-011 Implementar roles.
- [ ] PG-012 Implementar recuperación.
- [ ] PG-013 Configurar manejo global de excepciones.
- [ ] PG-014 Configurar perfiles de entorno.
- [ ] PG-015 Configurar secretos fuera de Git.

**Checkpoint:** cualquier módulo posterior puede confiar en identidad y autorización base.

### Fase 2 — Perfil y privacidad

Corresponde a SPEC-02.

- [ ] PG-016 Perfil personal.
- [ ] PG-017 Ubicación.
- [ ] PG-018 Separación zona/dirección.
- [ ] PG-019 Solicitud de eliminación.
- [ ] PG-020 Cifrado de campos sensibles.

### Fase 3 — Catálogo, storage y solicitudes

Corresponde a SPEC-04.

- [ ] PG-021 Crear `catalogo`.
- [ ] PG-022 Crear seeds iniciales de categorías/zonas.
- [ ] PG-023 Crear `ArchivoStorageService`.
- [ ] PG-024 Implementar adapter S3-compatible.
- [ ] PG-025 Implementar solicitudes.
- [ ] PG-026 Historial de solicitudes.
- [ ] PG-027 Idempotencia de comandos.

### Fase 4 — Perfil profesional

Corresponde a SPEC-05.

- [ ] PG-028 Crear perfil profesional.
- [ ] PG-029 Categorías y zonas ofrecidas.
- [ ] PG-030 Experiencia.
- [ ] PG-031 Portafolio.
- [ ] PG-032 Disponibilidad.
- [ ] PG-033 Agenda.
- [ ] PG-034 DTO público canónico.

### Fase 5 — Descubrimiento

Cierra la integración real de SPEC-03.

- [ ] PG-035 Reemplazar fixtures de SPEC-03 por servicios reales.
- [ ] PG-036 Implementar filtros.
- [ ] PG-037 Verificar que nunca se exponga dirección/contacto privado.
- [ ] PG-038 Indexar consultas.

### Fase 6 — Compatibilidad y oportunidades

Corresponde a SPEC-06.

- [ ] PG-039 Implementar `CompatibilidadService`.
- [ ] PG-040 Tablero de oportunidades.
- [ ] PG-041 Detalle.
- [ ] PG-042 Medir p95.
- [ ] PG-043 Emitir evento `NUEVA_OPORTUNIDAD`.

### Fase 7 — Propuestas

Corresponde a SPEC-07.

- [ ] PG-044 Crear propuesta.
- [ ] PG-045 Editar.
- [ ] PG-046 Retirar.
- [ ] PG-047 Validar compatibilidad en creación.
- [ ] PG-048 Emitir evento `PROPUESTA_RECIBIDA`.

### Fase 8 — Contratación y servicio

Corresponde a SPEC-08.

- [ ] PG-049 Aceptar propuesta de forma atómica.
- [ ] PG-050 Cerrar las demás propuestas.
- [ ] PG-051 Crear `ServicioContratado`.
- [ ] PG-052 Implementar máquina de estados.
- [ ] PG-053 Implementar `@Version`.
- [ ] PG-054 Historial.
- [ ] PG-055 Comunicación del servicio.
- [ ] PG-056 Integrar bloqueo de eliminación de cuenta.

### Fase 9 — Notificaciones unificadas

Corresponde a SPEC-09 y consolida SPEC-06/07.

- [ ] PG-057 Crear modelo genérico.
- [ ] PG-058 Definir claves de idempotencia.
- [ ] PG-059 Crear worker.
- [ ] PG-060 Implementar FCM.
- [ ] PG-061 Implementar reintentos.
- [ ] PG-062 Migrar oportunidad/propuesta al patrón común.
- [ ] PG-063 Endpoint de historial.
- [ ] PG-064 Métricas de entrega.

### Fase 10 — Infraestructura de piloto

- [ ] PG-065 VPS endurecido.
- [ ] PG-066 Docker Compose de producción.
- [ ] PG-067 Reverse proxy.
- [ ] PG-068 TLS.
- [ ] PG-069 Firewall.
- [ ] PG-070 Backups.
- [ ] PG-071 Monitoreo.
- [ ] PG-072 Alertas.
- [ ] PG-073 Smoke tests.
- [ ] PG-074 Runbook de despliegue/rollback.

### Fase 11 — Integración móvil/web

- [ ] PG-075 Cliente HTTP común.
- [ ] PG-076 almacenamiento seguro de token móvil.
- [ ] PG-077 navegación por rol.
- [ ] PG-078 manejo offline/reintentos.
- [ ] PG-079 push notifications.
- [ ] PG-080 panel administrativo base.
- [ ] PG-081 E2E Cliente.
- [ ] PG-082 E2E Prestador.

---

## 28. Paralelización segura

Después de SPEC-01:

```text
SPEC-02
SPEC-04
base de app móvil
base de panel web
infraestructura CI/CD
```

pueden avanzar parcialmente en paralelo.

Después de SPEC-04:

```text
SPEC-05
storage
optimización de solicitudes
```

Después de SPEC-05:

```text
SPEC-03 integración real
SPEC-06
```

Después de SPEC-06:

```text
SPEC-07
```

Después de SPEC-07:

```text
SPEC-08
```

Después de SPEC-08:

```text
SPEC-09
integración eliminación de cuenta
```

---


---

## 29. Escalabilidad

Para el piloto:

```text
~50–100 Prestadores
~200–500 Clientes
```

no se requiere:

- Kubernetes;
- Kafka;
- microservicios;
- clúster PostgreSQL;
- service mesh.

### Camino de evolución

Si la carga lo exige:

1. separar worker de notificaciones;
2. añadir Redis para caché/rate-limit si las métricas lo justifican;
3. añadir cola/broker;
4. escalar backend horizontalmente;
5. mover PostgreSQL a servicio administrado;
6. extraer un módulo a servicio independiente solo si existe una razón medible.

---

## 30. Datos seed iniciales

Debe existir una migración o proceso controlado para:

### Categorías

Ejemplos provenientes del planteamiento:

- aire acondicionado;
- electricidad;
- plomería;
- pintura;
- mantenimiento;
- electrodomésticos;
- instalación de equipos.

### Zonas

La fuente definitiva y granularidad deben validarse antes del piloto.

No codificar las zonas permanentemente en el frontend.

---

## 31. Decisiones pendientes que deben cerrarse antes de producción

### P-01 — Estados exactos de transición del servicio

Definir si:

```text
CONTRATADO -> TERMINADO
```

es válido o si siempre requiere:

```text
CONTRATADO -> EN_EJECUCION -> TERMINADO
```

### P-02 — Modelo exacto de disponibilidad

Definir:

- recurrencia semanal;
- excepciones;
- fechas puntuales;
- timezone.

### P-03 — Experiencia profesional

Cerrar campos formales de `ExperienciaProfesional`.

### P-04 — Seed y administración de catálogo

Definir:

- listado inicial;
- responsable;
- política de desactivación;
- tratamiento de categorías históricas.

### P-05 — Proveedor productivo de storage

El contrato queda cerrado; el proveedor puede elegirse posteriormente.

### P-06 — Proveedor productivo de notificaciones

FCM es la opción propuesta para móvil, pero las credenciales y configuración final deben formalizarse.

### P-07 — Objetivo numérico de RNF-003

El plan usa provisionalmente p95 <= 500 ms para lecturas principales.

### P-08 — Alcance exacto del panel Administrador

La Plantilla lo requiere, pero los SPEC-01 a SPEC-09 no detallan todavía moderación, reportes y auditoría.

---

## 33. Riesgos técnicos y mitigación

| Riesgo | Impacto | Mitigación |
|---|---:|---|
| Duplicidad de notificaciones | Alto | modelo genérico + idempotencia |
| Filtración de ubicación exacta | Alto | DTO público único + tests de privacidad |
| Aceptación simultánea de propuestas | Alto | constraint + transacción + locking |
| Reintentos por mala conexión | Alto | Idempotency-Key |
| Estados inconsistentes | Alto | máquina de estados + historial |
| Archivos maliciosos | Medio/Alto | validación MIME/tamaño + storage privado |
| Caída de proveedor push | Medio | persistir antes de entregar + reintentos |
| VPS único | Medio | backup externo + runbook de restauración |
| Consultas de compatibilidad lentas | Medio | índices + medición + optimización dirigida |
| Acoplamiento entre módulos | Medio | contratos de servicio internos |
| Crecimiento prematuro de infraestructura | Medio | mantener monolito modular en MVP |

---

## 34. Definición de listo — infraestructura

La infraestructura del MVP se considera lista cuando:

- [ ] todo el tráfico público usa HTTPS;
- [ ] PostgreSQL no es accesible desde Internet;
- [ ] secretos no están en Git;
- [ ] Flyway aplica desde una DB vacía;
- [ ] backups están automatizados;
- [ ] una restauración fue probada;
- [ ] health checks funcionan;
- [ ] logs poseen `traceId`;
- [ ] métricas de p95 están disponibles;
- [ ] FCM/proveedor de notificaciones puede fallar sin revertir el negocio;
- [ ] storage puede fallar sin corromper datos;
- [ ] existe CI;
- [ ] tests críticos bloquean despliegue;
- [ ] existe rollback documentado.

---

## 35. Definición de listo — MVP funcional

El MVP integrado está listo cuando los dos flujos siguientes son verificables de extremo a extremo.

### Cliente

```text
Registro
→ Login
→ Perfil/privacidad
→ Publicar solicitud
→ Recibir propuestas
→ Aceptar una
→ Consultar servicio
→ Comunicarse dentro del servicio
→ Confirmar finalización
→ Recibir notificaciones
```

### Prestador

```text
Registro
→ Login
→ Crear perfil profesional
→ Configurar categorías/zonas/disponibilidad
→ Consultar oportunidad compatible
→ Crear propuesta
→ Ser contratado
→ Gestionar ejecución
→ Marcar terminado
→ Consultar historial
→ Recibir notificaciones
```

---

## 36. Arquitectura objetivo del MVP

```mermaid
flowchart TB
    subgraph ClientSide[Clientes]
      RN[React Native\nCliente + Prestador]
      WEB[React Admin]
    end

    subgraph Edge[Edge]
      TLS[Reverse Proxy\nTLS / Rate Limit]
    end

    subgraph App[ALIADO Backend - Spring Boot]
      AUTH[Auth]
      PER[Perfil]
      CAT[Catálogo]
      SOL[Solicitudes]
      PPRO[Perfil profesional]
      DES[Descubrimiento]
      OPP[Oportunidades]
      PRO[Propuestas]
      SER[Servicios]
      NOT[Notificaciones]
      COM[Common]
    end

    subgraph Data[Datos]
      PG[(PostgreSQL)]
      S3[(S3-compatible)]
    end

    subgraph External[Externos]
      FCM[Firebase Cloud Messaging]
      EMAIL[Proveedor email]
    end

    subgraph Ops[Operación]
      METRICS[Métricas]
      LOGS[Logs]
      BACKUP[Backups]
    end

    RN --> TLS
    WEB --> TLS
    TLS --> AUTH
    TLS --> PER
    TLS --> CAT
    TLS --> SOL
    TLS --> PPRO
    TLS --> DES
    TLS --> OPP
    TLS --> PRO
    TLS --> SER
    TLS --> NOT

    AUTH --> PG
    PER --> PG
    CAT --> PG
    SOL --> PG
    PPRO --> PG
    OPP --> PG
    PRO --> PG
    SER --> PG
    NOT --> PG

    SOL --> S3
    PPRO --> S3
    NOT --> FCM
    AUTH --> EMAIL

    App --> METRICS
    App --> LOGS
    PG --> BACKUP
    S3 --> BACKUP
```

---

## 37. Resultado esperado del plan general

El resultado de ejecutar este plan debe ser una plataforma ALIADO con:

- arquitectura modular coherente;
- infraestructura reproducible;
- autenticación y privacidad centralizadas;
- datos consistentes;
- módulos desacoplados por responsabilidad;
- almacenamiento de archivos sustituible;
- notificaciones confiables;
- soporte para conectividad intermitente;
- trazabilidad de estados;
- pruebas automatizadas;
- despliegue en VPS mediante contenedores;
- capacidad de evolucionar hacia los módulos de reputación, moderación y administración sin reescribir el núcleo.

---

## 38. Fuentes documentales internas utilizadas

- `Plantilla-Proyecto-ALIADO.md`
- `plan-template.md`
- `plan-spec-01-autenticacion.md`
- `plan-spec-02-perfil.md`
- `plan-spec-03-descubrimiento.md`
- `plan-spec-04-gestion-solicitudes-servicio.md`
- `plan-spec-05-perfil-profesional.md`
- `plan-spec-06-compatibilidad-oportunidades.md`
- `plan-spec-07-creacion-gestion-propuestas.md`
- `plan-spec-08-contratacion-ciclo-servicio.md`
- `plan-spec-09-notificaciones-propuestas-servicios.md`

---

## 39. Nota

Los planes por SPEC son documentos de implementación local. Este `plan-general.md` debe utilizarse como documento rector para decisiones transversales.

Cuando exista una contradicción:

1. los requerimientos funcionales y de aceptación del SPEC conservan prioridad sobre detalles de implementación;
2. las decisiones de infraestructura compartida se resuelven una sola vez en este documento;
3. cualquier cambio que afecte múltiples módulos debe registrarse como ADR en `docs/architecture/decisions/`;
4. los planes de SPEC afectados deben actualizarse para mantener consistencia.

El objetivo es impedir que cada módulo resuelva de forma independiente problemas ya solucionados por la arquitectura global.
